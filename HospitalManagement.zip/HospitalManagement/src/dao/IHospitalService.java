package dao;

import myhospital.entity.Appointment;
import java.util.List;

	public interface IHospitalService {
		  Appointment getAppointmentById(int appointmentId);
		  List<Appointment> getAppointmentsForPatient(int patientId);
		  List<Appointment> getAppointmentsForDoctor(int doctorId);
		  boolean scheduleAppointment(Appointment appointments);
		  boolean updateAppointment(Appointment appointments) ;
		  boolean cancelAppointment(int appointmentId);
		  
		
		

	}
