package dao;

import myhospital.entity.Appointment;
import exception.PatientNumberNotFoundException;
import util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import util.DBConnUtil;

public class HospitalServiceImpl implements IHospitalService {
    private Connection conn;

    public HospitalServiceImpl() {
    	this.conn  = DBConnUtil.getConnect();
    }

    @Override
    public Appointment getAppointmentById(int appointmentId) {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Appointment WHERE appointmentId = ?");
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getString("appointmentDate"),
                        rs.getString("description")
                );
            } else {
            	throw new PatientNumberNotFoundException("Appointment ID not found: " + appointmentId);
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) {
        List<Appointment> appointments = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Appointment WHERE patientId = ?");
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                appointments.add(new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getString("appointmentDate"),
                        rs.getString("description")
                ));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return appointments;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        List<Appointment> appointments = new ArrayList<>();
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Appointment WHERE doctorId = ?");
            ps.setInt(1, doctorId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                appointments.add(new Appointment(
                        rs.getInt("appointmentId"),
                        rs.getInt("patientId"),
                        rs.getInt("doctorId"),
                        rs.getString("appointmentDate"),
                        rs.getString("description")
                ));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return appointments;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment) {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Appointment (patientid, doctorId, appointmentDate, description) VALUES (?, ?, ?, ?)");
            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setString(3, appointment.getAppointmentDate());
            ps.setString(4, appointment.getDescription());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateAppointment(Appointment appointment) {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE Appointment SET patientId = ?, doctorId = ?, appointmentDate = ?, description = ? WHERE appointmentId = ?");
            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setString(3, appointment.getAppointmentDate());
            ps.setString(4, appointment.getDescription());
            ps.setInt(5, appointment.getAppointmentId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean cancelAppointment(int appointmentId) {
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Appointment WHERE appointmentId = ?");
            ps.setInt(1, appointmentId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return false;
    }
}