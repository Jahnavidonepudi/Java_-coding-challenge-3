package Main;

import dao.HospitalServiceImpl;
import myhospital.entity.Appointment;
import exception.PatientNumberNotFoundException;

import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HospitalServiceImpl service = new HospitalServiceImpl();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule Appointment");
            System.out.println("5. Update Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("7. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter Appointment ID: ");
                    int appointmentId = scanner.nextInt();
                    try {
                        Appointment appointment = service.getAppointmentById(appointmentId);
                        System.out.println(appointment);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("Enter Patient ID: ");
                    int patientId = scanner.nextInt();
                    List<Appointment> patientAppointments = service.getAppointmentsForPatient(patientId);
                    for (Appointment a : patientAppointments) {
                        System.out.println(a);
                    }
                    break;
                case 3:
                    System.out.print("Enter Doctor ID: ");
                    int doctorId = scanner.nextInt();
                    List<Appointment> doctorAppointments = service.getAppointmentsForDoctor(doctorId);
                    for (Appointment a : doctorAppointments) {
                        System.out.println(a);
                    }
                    break;
                case 4:
                    System.out.print("Enter Patient ID: ");
                    int pId = scanner.nextInt();
                    System.out.print("Enter Doctor ID: ");
                    int dId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                    String date = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String desc = scanner.nextLine();
                    Appointment newAppointment = new Appointment(0, pId, dId, date, desc);
                    if (service.scheduleAppointment(newAppointment)) {
                        System.out.println("Appointment scheduled successfully.");
                    } else {
                        System.out.println("Failed to schedule appointment.");
                    }
                    break;
                case 5:
                    System.out.print("Enter Appointment ID: ");
                    int apptId = scanner.nextInt();
                    System.out.print("Enter Patient ID: ");
                    int ptId = scanner.nextInt();
                    System.out.print("Enter Doctor ID: ");
                    int docId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                    String apptDate = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String apptDesc = scanner.nextLine();
                    Appointment updatedAppointment = new Appointment(apptId, ptId, docId, apptDate, apptDesc);
                    if (service.updateAppointment(updatedAppointment)) {
                        System.out.println("Appointment updated successfully.");
                    } else {
                        System.out.println("Failed to update appointment.");
                    }
                    break;
                case 6:
                    System.out.print("Enter Appointment ID: ");
                    int cancelId = scanner.nextInt();
                    if (service.cancelAppointment(cancelId)) {
                        System.out.println("Appointment cancelled successfully.");
                    } else {
                        System.out.println("Failed to cancel appointment.");
                    }
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
